package com.example.nybooks.data.model

data class Book(
    val title: String,
    val author: String
)