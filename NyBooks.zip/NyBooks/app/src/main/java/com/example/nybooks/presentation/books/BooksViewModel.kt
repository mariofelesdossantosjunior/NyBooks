package com.example.nybooks.presentation.books

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.nybooks.data.ApiService
import com.example.nybooks.data.model.Book
import com.example.nybooks.data.response.BookBodyResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BooksViewModel : ViewModel() {

    val booksLiveData: MutableLiveData<List<Book>> = MutableLiveData()

    fun getBooks(){
       // booksLiveData.value = createFakeBooks();
        ApiService.service.getBooks().enqueue(object: Callback<BookBodyResponse>{
           override fun onResponse(call: Call<BookBodyResponse>,response: Response<BookBodyResponse>) {
               if (response.isSuccessful) {
                   val books: MutableList<Book> = mutableListOf()

                   response.body()?.let { bookBodyResponse ->
                       for (result in bookBodyResponse.bookResults) {
                           val book = result.bookDetailResponses[0].getBookModel()
                           books.add(book)
                       }
                   }

                   booksLiveData.value = books
               }
           }

           override fun onFailure(call: Call<BookBodyResponse>, t: Throwable) {
               Log.e(TAG, t.message.toString())
           }

       })
    }

    fun createFakeBooks(): List<Book>{
        return listOf(
            Book("Titulo 1 ", "Author 1"),
            Book("Titulo 2 ", "Author 2"),
            Book("Titulo 3 ", "Author 3")
        )
    }

    companion object{
        val TAG = BooksViewModel::class.java.simpleName
    }

}